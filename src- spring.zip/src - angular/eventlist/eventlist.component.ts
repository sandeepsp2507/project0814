
import { Component, OnInit } from '@angular/core';
import { EventListService } from "src/eventlist/eventlist.service";
import { EventList } from "src/eventlist/eventlist.interface";



export class FeatureModule {}
@Component({
    selector:"event-root",
    templateUrl:"./eventlist.component.html"
})

export class EventListComponent implements OnInit{
 
  title='Event Lists'
  eventlist :EventList[]= [];
  errorMessage:string;

     constructor( private eventlistservice:EventListService ) { 
  }

ngOnInit(): void {
  this.eventlistservice.getEventList().subscribe(
  eventlist =>{
  this.eventlist = eventlist;
},
error =>this.errorMessage = error

  );
}


}
