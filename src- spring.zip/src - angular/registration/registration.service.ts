
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Registration } from './registration';

@Injectable({
providedIn:'root'

})

export class RegistrationService{

    constructor(private httpSer:HttpClient) {
    }

    config = {headers : {
            "Content-Type": "application/json; charset = utf-8;"
        }
    };

    url='http://localhost:9058/system/registration';

    enroll(user : Registration){ 

        console.log(user);
       
        return this.httpSer.post(this.url, user);
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
       
    }
    
}
   