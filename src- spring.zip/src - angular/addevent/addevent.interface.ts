export interface EventList{
    teamid:number;
    sportsname:string;
    date:string;
    venue:string;
    entryfee:number;
    firstprice:number;
    secondprice:number;
    thirdprice:number;
}