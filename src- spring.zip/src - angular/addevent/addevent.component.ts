
import { Component, OnInit } from '@angular/core';
import { AddEventService } from "../addevent/addevent.service";
import { EventList } from "../addevent/addevent.interface";



export class FeatureModule {}
@Component({
    selector:"event-root",
    templateUrl:"./addevent.component.html",
    styleUrls:["./addevent.component.css"]
})

export class AddeventComponent implements OnInit{
 
  title='Event Lists'
  eventlist :EventList[]= [];
  errorMessage:string;

     constructor( private addeventService:AddEventService ) { 
  }

ngOnInit(): void {
  this.addeventService.getEventList().subscribe(
  eventlist =>{
  this.eventlist = eventlist;
},
error =>this.errorMessage = error

  );
}


DeleteEvent(teamid:number):void{
    this.addeventService.DeleteEvent(teamid).subscribe(
        data=>{console.log(data);
        this.addeventService.getEventList().subscribe(data=>{
            this.eventlist=data;}

        )}
    )
}

}
