import { Component } from '@angular/core';
import { AuthenticationService } from "src/gaurds/authentication.service";
import { Router } from "@angular/router";
import { Location } from "@angular/common";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  title = 'sport';
  constructor( private auth:AuthenticationService,private router : Router,private location:Location){}

  logout(){
    this.auth.getLoggedIn(false);
    this.router.navigate(['/admin']);
    window.alert("You're logged out succesfully");
  }

  login(){
    this.router.navigate(['/admin']);
  }
  goBack()
  {
    this.location.back();
    console.log('goBack()....');
  }
}
