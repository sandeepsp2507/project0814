import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SportComponent } from '../sport/sport.component';
import { adminComponent } from '../admin/admin.component';
import { userComponent } from '../user/user.component';
import { registrationComponent } from '../registration/registration.component';
import { adminsubmitComponent } from '../adminsubmit/adminsubmit.component';
import { cricketdetailComponent } from '../cricketdetail/cricketdetail.component';
import { homeComponent } from '../home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { AboutComponent } from '../AboutUs/About.component';
import {EventListComponent} from '../eventlist/eventlist.component';
import {AddeventComponent} from '../addevent/addevent.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { RouterModule } from "@angular/router";
import {ListComponent} from "../view/view.component";
// import { LogoutComponent } from "src/logout/logout.component";


@NgModule({
  declarations: [
    AppComponent,SportComponent,adminComponent,userComponent,registrationComponent,adminsubmitComponent,
    cricketdetailComponent,homeComponent,AboutComponent,EventListComponent,AddeventComponent,ListComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
