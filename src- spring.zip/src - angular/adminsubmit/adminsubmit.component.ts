import { Component, OnInit}from '@angular/core';
import { sportService } from './adminsubmit.service';
import { sportsevent } from './adminsubmit';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
    selector: 'adminsubmit-root',
  templateUrl: './adminsubmit.component.html'
  //styleUrls:['./adminsubmit.component.css']
})
export class adminsubmitComponent implements  OnInit{ 
 

ngOnInit(): void {
  
}
  
constructor(private sposervice:sportService,private route: ActivatedRoute, private router: Router) {
}


admin = new sportsevent();


  save(regForm:NgForm){

        console.log("Saved Form" + this.admin);

        this.sposervice.enroll(this.admin).subscribe(
            data => console.log('Success !!' , data),
            // error => console.error('Error !!' , error)
        )

        this.router.navigate(['/home']);
    }
  
}
