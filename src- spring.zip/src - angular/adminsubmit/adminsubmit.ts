export class sportsevent{
    constructor(
     public teamid='', 
         public sportsname='', 
            public date='', 
            public venue='',
            public entryfee='',
            public firstprice='',
            public secondprice='',
             public thirdprice=''){}
}