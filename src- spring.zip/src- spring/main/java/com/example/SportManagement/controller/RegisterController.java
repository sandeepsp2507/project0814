package com.example.SportManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SportManagement.bean.Register;
import com.example.SportManagement.bean.Sports;
import com.example.SportManagement.dao.RegisterDao;
import com.example.SportManagement.dao.SportsManagementDao;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/system")
public class RegisterController {
	@Autowired
	private RegisterDao dao1;
	
	@PostMapping("registration")
	
	public String Register(@RequestBody Register reg){
	System.out.println("Registered");
	
	dao1.save(reg);
	return "registered";
	}

	@Autowired
	private RegisterDao dao;

	@GetMapping("registration")
	public List<Register> getRegister(){
		System.out.println("REceived request");
		return (List<Register>) dao.findAll();
	}

}
