Sports Management

Overview:
* Project is about sports management.
* Admin can login and add the ongoing events along with the price money, venue, date.
* user can view the events and register to the required sports event.

Technologies:
* Angular framework
* Spring boot
* My SQL
* JAVA 
* BOOTSTRAP
* HTML & CSS

Dependencies:
* Web starter
* JPA
* My SQL

 Known Issues:
* we faced issue while connecting to the database using spring boot.
* we faced issues while inserting the data into database.
 
Steps To Build And Run:

* Create MySQL database with name sports Management, create tables by using the bean in src.
* Run the Angular code in command prompt.
* Check the output in browser with respect to the port number.



