import { EventList } from './eventlist.interface';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable({
providedIn:'root'

})

export class EventListService{

    //customerUrl = 'http://localhost:9090/customer';
    sportsUrl='/sports';

    constructor(private httpSer:HttpClient) {
    }


    getEventList():Observable<EventList[]>{
    
        return this.httpSer.get<EventList[]>("//localhost:9058/sports").pipe(
        tap(data => console.log('EventList : '+JSON.stringify(data))),
        catchError(this.handleError)
    );
    }

    private handleError(err:HttpErrorResponse){
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
       
    }
     public createUser(event) {
    return this.httpSer.post<EventList>("//localhost:9058/sports", Event);
  }

}
