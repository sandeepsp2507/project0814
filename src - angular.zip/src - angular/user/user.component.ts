import { Component,OnInit}from '@angular/core';
import { user } from './user';
import { NgForm } from '@angular/forms';
@Component({
    selector: 'user-root',
  templateUrl: './user.component.html',
  styleUrls:['./user.component.css']
})
export class userComponent implements OnInit{ 
  
  
    ngOnInit(): void {
        
    }
 
 
 
    regis = new user();

constructor() {
   
    
}

save(regisForm:NgForm){
console.log(regisForm.form);
console.log('Saved data ' + JSON.stringify(regisForm.value) )
    
}
}