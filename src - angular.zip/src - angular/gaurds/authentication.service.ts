import { Injectable } from '@angular/core';
import { Router } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private router : Router) { }
  loggedInStatus:boolean;
  getLoggedIn(value:any) {

      console.log("inside gaurd service");
      this.loggedInStatus=value;
        console.log(this.loggedInStatus);
      
  }

  isLoggedIn() {
      return this.loggedInStatus;
  }

  
}