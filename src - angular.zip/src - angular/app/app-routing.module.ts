import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SportComponent } from 'src/sport/sport.component';
import { adminComponent } from '../admin/admin.component';
import { userComponent } from '../user/user.component';
import { registrationComponent } from '../registration/registration.component';
import { adminsubmitComponent } from '../adminsubmit/adminsubmit.component';
import { cricketdetailComponent } from '../cricketdetail/cricketdetail.component';
import { AboutComponent } from '../AboutUs/About.component';
import {EventListComponent} from '../eventlist/eventlist.component';
import { homeComponent } from '../home/home.component';
import {AddeventComponent} from '../addevent/addevent.component';
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms/forms";
import { AuthGaurdService } from "src/gaurds/AuthGaurd.service";
import {ListComponent} from "../view/view.component";
//import { AuthGaurdService } from "src/gaurds/AuthGaurd.service";
// import { LogoutComponent } from "src/logout/logout.component";
const routes: Routes = [
  {path:'sport',component:SportComponent},
  {path:'admin',component:adminComponent},  
  //  {path:'logout',component:LogoutComponent}, 
  {path:'user',component:userComponent},
  {path:'registration',component:registrationComponent},
  {path:'adminsubmit',component:adminsubmitComponent,canActivate : [AuthGaurdService]},
  {path:'adminsubmit/:id',component:cricketdetailComponent},
  {path:'registration/:name',component:registrationComponent},
  {path:'addevent',component:AddeventComponent,canActivate : [AuthGaurdService]},
  {path:'home',component:homeComponent},
  {path:'',component:homeComponent},
  {path:'AboutUs',component:AboutComponent},
  {path:'view',component:ListComponent,canActivate : [AuthGaurdService]},
  {path:'eventlist',component:EventListComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes),BrowserModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
