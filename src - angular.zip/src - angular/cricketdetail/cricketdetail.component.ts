import { sportsevent } from '../adminsubmit/adminsubmit';
import { ActivatedRoute, Router } from '@angular/router';
import { OnInit, Component } from '@angular/core';
import { EventList } from "src/eventlist/eventlist.interface";


@Component({
    templateUrl: './cricketdetail.component.html',
 styleUrls: ['./cricketdetail.component.css']
})
export class cricketdetailComponent implements OnInit {
    pgid: string= "sportsid";

    // pagetitle: string="sportsname";
    sport: EventList;
    constructor(private route: ActivatedRoute, private router: Router) { };

    ngOnInit() {

        let id = +this.route.snapshot.paramMap.get('teamid');
        // let name = +this.route.snapshot.paramMap.get('sportsname');
        this.pgid +=  `: ${id}`;
        //  this.pagetitle +=  `: ${name}`;
        this.sport = {
             'teamid':id, 
             'sportsname':'name', 
             'date':'01/08/2019', 
             'venue':'vijayanagar',
             'entryfee':133,
             'firstprice':1,
             'secondprice':10,
             'thirdprice':10
        };

    }

    onBack(): void {

        this.router.navigate(['/eventlist']);
    }
     onRegister(): void {
        
        this.router.navigate(['/registration']);
    }

}

