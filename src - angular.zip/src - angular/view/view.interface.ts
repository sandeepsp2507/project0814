export interface List{
    sportsname:string;
    teamname:string;
    email:string;
    mobilenumber:number;
}