
import { Component, OnInit } from '@angular/core';
import { ListService } from "src/view/view.service";
import { List } from "src/view/view.interface";



export class FeatureModule {}
@Component({
    selector:"event-root",
    templateUrl:"./view.component.html",
    styleUrls: ['./view.component.css']
})

export class ListComponent implements OnInit{
 
  title='Registered Lists'
  list :List[]= [];
  errorMessage:string;

     constructor( private listservice:ListService ) { 
  }

ngOnInit(): void {
  this.listservice.getList().subscribe(
  list =>{
  this.list = list;
},
error =>this.errorMessage = error

  );
}


}
