export class admin{
constructor(
public username='',
public password ='',
)
{}


}