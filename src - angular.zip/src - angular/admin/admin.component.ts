import { Component,OnInit}from '@angular/core';
import { admin } from '../admin/admin';
import { NgForm } from '@angular/forms';
import { Router } from "@angular/router";
import { AuthenticationService } from "src/gaurds/authentication.service";
import { AuthGaurdService } from "src/gaurds/AuthGaurd.service";
import { HttpClient } from "@angular/common/http";
import { adminServiceComponent } from "src/admin/admin.service";
@Component({
    selector: 'admin-root',
  templateUrl: './admin.component.html',
  styleUrls:['./admin.component.css']
})
export class adminComponent{ 
  
   errorMessage:string;
  
    // ngOnInit(): void {
        
    // }
 

constructor(private router:Router,private http:HttpClient,private loginservice:adminServiceComponent,
private auth:AuthenticationService) {
   
    
}
regis = new admin();
    isPresent:boolean;

save()
{
    
     console.log('Saved Form'+ JSON.stringify(this.regis));
     this.loginservice.enroll(this.regis).subscribe(
         data=>{this.auth.getLoggedIn(data)
         if(data==true){
             this.router.navigate(['/addevent']);

         }else if(data == false){  
                           
          window.alert("username or password is wrong")
        }
    },
    error=>window.alert("something is wrong")

     )
    
    
}
}