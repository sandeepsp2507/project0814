
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import {tap, catchError} from 'rxjs/operators';
import { Injectable } from '@angular/core';

import { admin } from "src/admin/admin";

@Injectable({
providedIn:'root'

})

export class adminServiceComponent{

    constructor(private httpSer:HttpClient) {
    }

    url='http://localhost:9058/login';

    enroll(regis : admin){ 

        console.log(regis);
       
        return this.httpSer.post('http://localhost:9058/login', regis);
    }    
}
   