import { Component,OnInit}from '@angular/core';
import {  Registration } from '../registration/registration';
import { NgForm } from '@angular/forms';


import { RegistrationService } from "./registration.service";
import { ActivatedRoute, Router } from '@angular/router';
@Component({
    selector: 'registration-root',
  templateUrl: './registration.component.html',
  styleUrls:['./registration.component.css']
})
export class registrationComponent implements OnInit{ 

sportsname="";

   ngOnInit(): void {
        let name = this.route.snapshot.paramMap.get('name'); 
        console.log(name);
        this.sportsname += `${name}`;
        this.user.sportsname += `${name}`;
    }

    constructor( private registrationservice:RegistrationService,private route: ActivatedRoute, private router: Router ) { 
  }
user = new Registration();


  save(regForm:NgForm){

        console.log("Saved Form" + this.user);

        this.registrationservice.enroll(this.user).subscribe(
            data => console.log('Success !!' , data),
            // error => console.error('Error !!' , error)
        )

        this.router.navigate(['/eventlist']);
    }



}
