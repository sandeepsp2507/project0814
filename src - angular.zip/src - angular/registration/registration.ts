export class Registration{
    constructor(
        public sportsname='',
public teamname='',

public email='',
public mobilenumber=''){}


}